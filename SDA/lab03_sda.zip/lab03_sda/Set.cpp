#include "Set.h"
#include "SetITerator.h"
#include "iostream"

//Average: Teta(1) / Teta(capacity)
//Worst: Teta(1) / Teta(capacity)
//Best: Teta(1) / Teta(capacity)
Set::Set() {
    capacity = 10;
    head = -1;
    length = 0;
    firstEmpty = 0;
    array = new Node[capacity];

    // initialize the next pointers of each node to point to the next slot in the array
    for (int i = 0; i < capacity - 1; i++) {
        array[i].next = i + 1;
        array[i].data = NULL_TELEM;
    }
    // the last node in the array has no next node
    array[capacity - 1].next = -1;
    array[capacity - 1].data = NULL_TELEM;
}

//Average: Teta(capacity)
//Worst: Teta(capacity)
//Best: Teta(capacity)
void Set::resize() {
    // No empty spots, need to resize the array
    int newCapacity = capacity * 2;
    Node *newArray = new Node[newCapacity];

    // Copy the old elements to the new array
    for (int i = 0; i < capacity; i++) {
        newArray[i].data = array[i].data;
        newArray[i].next = array[i].next;
    }

    // Set the next pointers of the new empty nodes
    for (int i = capacity; i < newCapacity - 1; i++) {
        newArray[i].next = i + 1;
        newArray[i].data = NULL_TELEM;
    }

    // the last node in the array has no next node
    newArray[newCapacity - 1].next = -1;
    newArray[newCapacity - 1].data = NULL_TELEM;

    // Update the variables of the set
    delete[] array;
    array = newArray;
    firstEmpty = capacity;
    capacity = newCapacity;

    // Update the head pointer
    if (head == -1) {
        // The set was empty before resizing
        head = 0;
    } else {
        // Find the last element in the set
        int current = head;
        while (array[current].next != -1) {
            current = array[current].next;
        }
        // Set the next pointer of the last element to the first empty node
        array[current].next = firstEmpty;
    }
}

//Average: Teta(n)
//Worst: Teta(n)
//Best: Teta(n)
void Set::size_down() {
    int newCapacity = capacity / 2;
    if (newCapacity < 10 || length > newCapacity) {
        return;
    }

    Node *newArray = new Node[newCapacity];

    // Copy the old elements to the new array
    int index = head;
    for (int i = 0; i < length; i++) {
        newArray[i].data = array[index].data;
        newArray[i].next = i + 1;
        index = array[index].next;
    }

    // Set the next pointers of the last node in the array
    newArray[length - 1].next = -1;

    // Update the variables of the set
    delete[] array;
    array = newArray;
    firstEmpty = length;
    capacity = newCapacity;

    // Update the head pointer
    head = 0;
}

//Average: Teta(n)
//Worst: Teta(n)
//Best: Teta(1) wenn resizing nicht benutzt wird
bool Set::add(TElem elem) {
    // If the element is already in the set, return false
    if (search(elem)) {
        return false;
    }

    if (length >= capacity || firstEmpty == -1) {
        this->resize();
    }

    // Find the index of the first empty node
    int index = firstEmpty;
    // When head is -1 then set is empty
    if (head == -1) {
        head = index;
        array[index].data = elem;
    } else {
        array[index].data = elem;

    }

    // Update firstEmpty to the next empty node
    int nextEmpty = array[index].next;
    while (nextEmpty != -1 && array[nextEmpty].data != NULL_TELEM) {
        nextEmpty = array[nextEmpty].next;
    }
    firstEmpty = nextEmpty;

    // Increase the length of the set
    length++;

    return true;
}

//Average: Teta(n)
//Worst: Teta(n)
//Best: Teta(1)
bool Set::remove(TElem elem) {
    if (length == 0) {
        return false;
    }
    int prevIndex = -1;
    int currentIndex = head;

    while (currentIndex != -1 && array[currentIndex].data != elem) {
        prevIndex = currentIndex;
        currentIndex = array[currentIndex].next;
    }

    if (currentIndex == -1) {
        // Element not found
        return false;
    }

    if (prevIndex == -1) {
        // Removing the first element in the set
        head = array[currentIndex].next;
    } else {
        // Removing an element that is not the first
        array[prevIndex].next = array[currentIndex].next;
    }

    // Add the removed node to the list of empty nodes
    array[currentIndex].next = firstEmpty;
    firstEmpty = currentIndex;


    length--;
    if (length == 0) {
        // If the set is now empty, reset the head and firstEmpty pointers
        head = -1;
        firstEmpty = 0;
        capacity = 10;
        delete[] array;
        array = new Node[capacity];
        for (int i = 0; i < capacity - 1; i++) {
            array[i].next = i + 1;
            array[i].data = NULL_TELEM;
        }
        array[capacity - 1].next = -1;
        array[capacity - 1].data = NULL_TELEM;

    }
    if (length <= capacity/4) {
        this->size_down();
    }
    return true;
}

//Average: Teta(n)
//Worst: Teta(n)
//Best: Teta(1)
bool Set::search(TElem elem) const {
    if (length == 0) {
        return false;
    }
    int current = head;
    while (current != -1 && array[current].data != elem) {
        current = array[current].next;
    }
    if (current != -1) {
        return true;
    } else {
        return false;
    }
}

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
int Set::size() const {
    return length;
}

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
bool Set::isEmpty() const {
    if (length == 0) {
        return true;
    }
    return false;
}

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
Set::~Set() {
    delete[] array;
}

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
SetIterator Set::iterator() const {
    return SetIterator(*this);
}

//pre:s Set, length>=1, head !=-1
//post: t Set, length_t=length, t-reverse of s
//Average: Teta(capacity)
//Worst: Teta(capacity)
//Best: Teta(capacity)

//PSEUDOCOD:
//reverse()
//if head = -1 or length <= 1
//        stop
//new_Array=dynamic Node[capacity];
//new_first_empty= capacity -firstempty + 1
//current = head
//for i = firstEmpty-1,0
//data(newArray[i]) = data(array[current]);
//next(newArray[i]) = next(array[current-2]);
//current = next(array(current))
//delete array;
//array = newArray;
//firstEmpty = new_first_empty;
//head = 0;
//write(size(reverse))

void Set::reverse() {
    if (head == -1 || length <=1) { // if the set is empty, return
        return;
    }
//    1 2 3 4 5 6 _ _ _ _
//    _ _ _ _ 6 5 4 3 2 1
    Node* newArray = new Node[capacity];
    int new_first_empty = capacity-firstEmpty+1;

    int current = head;
    for (int i = firstEmpty-1; i > 0; i--) {
        newArray[i].data = array[current].data;
        newArray[i].next = array[current-2].next;  // assign the next pointer to the index of the previous node
        current = array[current].next;
    }
    newArray[0].data = array[current].data;
    newArray[0].next = -1;  // set the next pointer of the first node to -1 to indicate the end of the reversed list

    delete[] array;
    array = newArray;
    firstEmpty = new_first_empty;
    head = 0;
    std::cout<<"Reversed Size=" << size()<<std::endl;
}

void Set::print() const {
    if (isEmpty()) {
        std::cout << "Set is empty." << std::endl;
        return;
    }
    std::cout << "Set: ";
    SetIterator it = iterator();
    while (it.valid()) {
        if (it.getCurrent() > -1000 || it.getCurrent() < 1000) {
            std::cout << it.getCurrent() << " ";
            it.next();
        }
    }
    std::cout << std::endl;
}