#include "SetIterator.h"
#include "Set.h"
#include <exception>
#include <stdexcept>
using namespace std;

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
SetIterator::SetIterator(const Set &m) : set(m) {
    current = set.head;
}

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
void SetIterator::first() {
    current = set.head;
}

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
void SetIterator::next() {
    if (valid()) {
        current = set.array[current].next;
    } else {
        throw exception();
    }
}

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
TElem SetIterator::getCurrent() {
    if (valid()) {
        return set.array[current].data;
    } else {
        throw exception();
    }
}

//Average: Teta(1)
//Worst: Teta(1)
//Best: Teta(1)
bool SetIterator::valid() const {
//    return current >= 0 && current < set.capacity && set.array[current].data != NULL_TELEM && set.length !=0;
    if (current == -1 || set.array[current].data == NULL_TELEM || set.length <= 0) {
        return false;
    }
    else
    {
        return true;
    }
}


