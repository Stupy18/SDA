#pragma once
#include "SortedIndexedList.h"


//DO NOT CHANGE THIS PART
class ListIterator{
	friend class SortedIndexedList;
private:
    SortedIndexedList &list;
    Node* current;
    ListIterator(const SortedIndexedList& list);

public:
    // sets the iterator to the first element of the list
    void first();

    // moves the iterator to the next element of the list
    void next();

    // checks if the iterator is valid (i.e. if it points to a valid element in the list)
    bool valid() const;

    // returns the element that the iterator is currently pointing to
    TComp getCurrent() const;

    void deleteCurrent();
};

