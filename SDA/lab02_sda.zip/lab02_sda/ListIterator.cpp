#include "ListIterator.h"
#include "SortedIndexedList.h"
#include <iostream>

using namespace std;

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
ListIterator::ListIterator(const SortedIndexedList& list) : list(const_cast<SortedIndexedList &>(list)) {
    current = list.head; // current wird als head der SortedIndexedList initialisiert
}

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
void ListIterator::first(){
    current = list.head;
}

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
void ListIterator::next(){
    if (!valid())
        throw exception();
    current = current->next;
}

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
bool ListIterator::valid() const{
    if (current == nullptr) {
        return false;
    }
    else {
        return true;
    }
}

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
TComp ListIterator::getCurrent() const {
    return current->info;
}


//Pseudocod:
//function deleteCurrent():
//if not valid:
//  throw exception
//toDelete = current
//if current == list.head:
//  list.head = current.next
//else:
//  current.prev.next = current.next
//if current == list.tail:
//  list.tail = current.prev
//else:
//  current.next.prev = current.prev
//current = current.next
//delete toDelete
//list.length--
//if list.length == 0:
//  current = null
//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
//pre_cond=Der Listiterator, der valid sein soll;
//          Die verkettete Liste,zu der der Iterator gehort; e gehort TElem
//post_cond=Lange soll dekrementiert;
//          der current Element soll geloscht sein;
//          wenn Liste=Lehr<=>current=nullptr;
//          wenn Element nicht allein war<=> current zeigt auf nachsten Element;
//          wenn Element head/tail der Liste war <=> head/tail mussen aktualisiert werden;

void ListIterator::deleteCurrent() {
    // Uberprüfen, ob der Iterator gultig ist
    if (!valid()) {
        throw exception();
    }
    // Die aktuelle Node in einer temporären Variable speichern
    Node* toDelete = current;
    // Wenn die aktuelle Node am Anfang der Liste ist, aktualisiere den Head-Zeiger, um auf die nachste Node zu zeigen
    if (current == list.head) {
        list.head = current->next;
    } else {
        // Ansonsten aktualisiere den Next-Zeiger der vorherigen Node, um auf die nächste Node zu zeigen
        current->prev->next = current->next;
    }
    // Wenn die aktuelle Node am Ende der Liste ist, aktualisiere den Tail-Zeiger, um auf die vorherige Node zu zeigen
    if (current == list.tail) {
        list.tail = current->prev;
    } else {
        // Ansonsten aktualisiere den Prev-Zeiger der nachsten Node, um auf die vorherige Node zu zeigen
        current->next->prev = current->prev;
    }
    // Aktualisiere den aktuellen Zeiger, um auf die nächste Node zu zeigen
    current = current->next;
    // Losche die Node, auf die der toDelete-Zeiger zeigt
    delete toDelete;
    // Verringere die Lange der Liste
    list.length--;
    // Wenn length=0, dann gibt es keine Elemenete mehr
    if (list.length == 0) {
        current = nullptr;
    }
}



