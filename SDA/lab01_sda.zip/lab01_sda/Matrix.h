//repräsentiert als schwachbesetzte Matrix (sparse),
//indem man ein dynamisches Array von Tupeln der Form (Zeile, Spalte, Wert) (Wert ≠ 0) benutzt,
//wobei die Tupel in lexikographischen Reihenfolge nach (Zeile, Spalte) gespeichert werden.

#pragma once

//DO NOT CHANGE THIS PART
typedef int TElem;
struct tupel {
    int Zeile;
    int Spalte;
    TElem Wert;
};

#define NULL_TELEM 0

class Matrix {

private:
    int nrLines_;
    int nrCols_;
    int cap;
    int nr_elements;
    tupel* element_;

//this is how i acces Wert in Matrix(i,j) z.B. => element[i * numCols + j].Wert

public:
	//constructor
    //O(nrLines * nrCols)
	Matrix(int nrLines, int nrCols);

	//returns the number of lines
    //teta(1)
	int nrLines() const;

	//returns the number of columns
    //teta(1)
	int nrColumns() const;

	//returns the element from line i and column j (indexing starts from 0)
	//throws exception if (i,j) is not a valid position in the Matrix
    //O(n)
	TElem element(int i, int j) const;

	//modifies the value from line i and column j
	//returns the previous value from the position
	//throws exception if (i,j) is not a valid position in the Matrix
    //O(n) oder wenn capacity voll ist, O(nrLines*nrCols)
	TElem modify(int i, int j, TElem e);

    //teta(n)
//    pseudocod:
//    function transposed():
//    pre:  i<nrLines_, j<nrCols_
//          m apartine Matrix(i,j), e apartine m,TElem, TElem(i,j)=e
//    post:m' apartine Matrix(j,i), e apartine m',TElem, Telem(j,i)=e
//        Matrix transpusa
//        for k=0 to nr_elements
//                i_original=element[k].i
//                j_original=element[k].j
//                value_original=element[k].value
//                transpusa<-transpusa.modify(i_original,j_original,value_original)

//            nrlines_<=>nrCols_
//            nr_elements<=>transpusa.nr_elements
//            cap<=>transpusa.cap
//            element_<=>transpusa.element_


    void transposed();
	
	// destructor
    //teta(1)
	~Matrix();

};
