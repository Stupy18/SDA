#include "Matrix.h"
#include <exception>
#include <stdexcept>
using namespace std;
//For example, consider the following sparse matrix:
//
//0 0 0 0
//5 8 0 0
//0 0 3 0
//0 6 0 0

//The tuple sparse matrix representation of this matrix would be:
//
//(1, 0, 5) -> k=0
//(1, 1, 8) -> k=1
//(2, 2, 3) -> k=2
//(3, 1, 6) -> k=3

//=> nr elements=4

//matrice transpusa=>
//0 5 0 0
//0 8 0 6
//0 0 3 0
//0 0 0 0
//
//The tuple sparse matrix representation of this matrix would be:
//
//(0, 1, 5) -> k=0
//(1, 1, 8) -> k=1
//(1, 3, 6) -> k=2
//(2, 2, 3) -> k=3

//=> nr elements=4



//O(nrLines * nrCols)
Matrix::Matrix(int nrLines, int nrCols) {
    this->nrLines_ = nrLines;
    this->nrCols_ = nrCols;
    this->cap = nrLines * nrCols;
    this->nr_elements = 0;
    this->element_ = new tupel[cap];
}

//teta(1)
int Matrix::nrLines() const {
    return nrLines_;
}

//teta(1)
int Matrix::nrColumns() const {
    return nrCols_;
}

//O(n)
TElem Matrix::element(int i, int j) const {
    // check if (i,j) is a valid position in the matrix
    if (i < 0 || i >= nrLines_ || j < 0 || j >= nrCols_) {
        throw std::out_of_range("Invalid position");
    }
    // search for the tuple with coordinates (i,j)
    for (int k = 0; k < nr_elements; k++) {
        if (element_[k].Zeile == i && element_[k].Spalte == j) {
            return element_[k].Wert;
        }
    }
    // if not found, return NULL_TELEM
    return NULL_TELEM;
}

//O(n) oder wenn capacity voll ist, O(nrLines*nrCols)
TElem Matrix::modify(int i, int j, TElem e) {
    if (i < 0 || i >= nrLines_ || j < 0 || j >= nrCols_) {
        throw std::out_of_range("Invalid position in matrix");
    }

    // Search for the position (i, j) in the array of tuples
    int k = 0;
    while (k < nr_elements && element_[k].Zeile < i) {
        k++;
    }
    while (k < nr_elements && element_[k].Zeile == i && element_[k].Spalte < j) {
        k++;
    }

    // If the position (i, j) already exists, update its value and return the previous value
    if (k < nr_elements && element_[k].Zeile == i && element_[k].Spalte == j) {
        TElem prev = element_[k].Wert;
        element_[k].Wert = e;
        return prev;
    }

    // If the position (i, j) doesn't exist, insert a new tuple with the given value
    tupel new_tupel;
    new_tupel.Zeile = i;
    new_tupel.Spalte = j;
    new_tupel.Wert = e;
    if (nr_elements == cap) {
        // If the array of tuples is full, double its capacity
        cap *= 2;
        tupel* new_element = new tupel[cap];
        for (int l = 0; l < nr_elements; l++) {
            new_element[l] = element_[l];
        }
        delete[] element_;
        element_ = new_element;
    }
    for (int l = nr_elements - 1; l >= k; l--) {
        element_[l + 1] = element_[l];
    }
    element_[k] = new_tupel;
    nr_elements++;

    // Return NULL_TELEM as there was no previous value at the given position
    return NULL_TELEM;
}

void Matrix::transposed() {

    Matrix transpusa(nrCols_, nrLines_);

    for (int k = 0; k < nr_elements; k++) {
        int i_orig = element_[k].Zeile;
        int j_orig = element_[k].Spalte;
        TElem value = element_[k].Wert;
        transpusa.modify(j_orig, i_orig, value);
    }

    std::swap(nrLines_, nrCols_);
    std::swap(nr_elements, transpusa.nr_elements);
    std::swap(cap, transpusa.cap);
    std::swap(element_, transpusa.element_);
    }


//teta(1)
Matrix::~Matrix() {
    delete[] this->element_;
}


