#pragma once


void testAll();