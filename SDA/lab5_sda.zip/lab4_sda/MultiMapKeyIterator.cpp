#include <stdexcept>
#include "MultiMapKeyIterator.h"
#include "MultiMap.h"


//Best: Teta(1)
//Average: Teta(n)
//Worst: Teta(n)
//pre:M multimap,i multimapkeyiterator, M[i]!=nullptr
//post:M multimap, M[i]=nullptr or M[i]=key,pos von Values=0
void MultiMapKeyIterator::nextKey()
{
    if (!valid())
        throw std::runtime_error("Invalid iterator!");

    if (currentNode->next != nullptr)
    {
        currentNode = currentNode->next;
    }
    else
    {
        // Move to the next non-empty bucket
        while (currentBucket < col.capacity && col.table[currentBucket] == nullptr){
            currentBucket++;
        }

        if (currentBucket < col.capacity)
        {
            currentNode = col.table[currentBucket];
        }
        else
        {
            currentNode = nullptr;
        }
    }

    if (currentNode != nullptr)
    {
        pos = 0;
    }
}


//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
//pre:M multimap,i multimapkeyiterator
//post:M multimap, M[i]!=nullptr, M[i]-key in multimap
MultiMapKeyIterator::MultiMapKeyIterator(const MultiMap& c) : col(c) {
    first();
    this->pos=0;
}

// Returns the current key
//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
//pre:M multimap,i multimapkeyiterator, M[i]!=nullptr
//post:key apartine M, M[i]=k
int MultiMapKeyIterator::getCurrent() const {
    if (!valid()) {
        throw std::runtime_error("Invalid iterator operation: getCurrent()");

    }
    return currentNode->key;
}
// Checks whether the iterator is valid (i.e., not at the end)
//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
//pre:M multimap,i multimapkeyiterator
//post:M multimap, M[i]!=nullptr-True else False
bool MultiMapKeyIterator::valid() const {
    return currentNode != nullptr;
}

// Moves the iterator to the first key-value pair
//Best: Teta(1)
//Average: Teta(n)
//Worst: Teta(n)
//pre:M multimap,i multimapkeyiterator
//post:M multimap, M[i]!=nullptr, M[i]-key in multimap
void MultiMapKeyIterator::first() {
    currentBucket = 0;
    currentNode = nullptr;

    // Find the first non-empty bucket
    while (currentBucket < col.capacity && col.table[currentBucket] == nullptr) {
        currentBucket++;
    }
    if (currentBucket < col.capacity) {
        currentNode = col.table[currentBucket];
    }
    this->pos=0;
}

