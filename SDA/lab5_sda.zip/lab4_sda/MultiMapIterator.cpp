#include <stdexcept>
#include "MultiMapIterator.h"
#include "MultiMap.h"



//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
MultiMapIterator::MultiMapIterator(const MultiMap& c) : col(c) {
    first();
    this->pos=0;
}

// Returns the current key-value pair of the iterator
//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
TElem MultiMapIterator::getCurrent() const {
    if (!valid()) {
        throw std::runtime_error("Invalid iterator operation: getCurrent()");

    }
    return std::make_pair(currentNode->key, currentNode->values[currentNode->amount - 1]);
}
// Checks whether the iterator is valid (i.e., not at the end)
//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
bool MultiMapIterator::valid() const {
    return currentNode != nullptr;
}

// Moves the iterator to the next key-value pair
//Best: Teta(1)
//Average: Teta(n)
//Worst: Teta(n)
void MultiMapIterator::next() {
    if (currentNode == nullptr) {
        throw std::runtime_error("Invalid iterator operation: next()");
    }

    if (currentNode->amount > 1 && currentNode->capacityNode>this->pos && currentNode->values[this->pos]!=NULL_TVALUE) {
        // Move to the next value of the current key
        this->pos++;
    }   else if (currentNode->next != nullptr) {
        // Move to the next node in the current bucket
        currentNode = currentNode->next;
    } else {
        // Move to the next non-empty bucket
        currentBucket++;
        while (currentBucket < col.capacity && col.table[currentBucket] == nullptr) {
            currentBucket++;
        }

        if (currentBucket < col.capacity) {
            currentNode = col.table[currentBucket];
        } else {
            currentNode = nullptr;
        }
    }
}

// Moves the iterator to the first key-value pair
//Best: Teta(1)
//Average: Teta(n)
//Worst: Teta(n)
void MultiMapIterator::first() {
    currentBucket = 0;
    currentNode = nullptr;

    // Find the first non-empty bucket
    while (currentBucket < col.capacity && col.table[currentBucket] == nullptr) {
        currentBucket++;
    }
    if (currentBucket < col.capacity) {
        currentNode = col.table[currentBucket];
    }
    this->pos=0;
}

