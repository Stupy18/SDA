#pragma once
#include<vector>
#include<utility>
//DO NOT INCLUDE MultiMapIterator

using namespace std;

//DO NOT CHANGE THIS PART
typedef int TKey;
typedef int TValue;
typedef std::pair<TKey, TValue> TElem;
#define NULL_TVALUE -111111
#define NULL_TELEM pair<int,int>(-111111, -111111)
class MultiMapIterator;

struct Node {
    TKey key;
    TValue* values;
    Node* next;
    int amount=0;
    int capacityNode=5;
};

class MultiMapKeyIterator;

class MultiMap
{
	friend class MultiMapIterator;
	friend class MultiMapKeyIterator;

private:
    // Hash table variables
    static const int INITIAL_CAPACITY = 13;
//    static const int CAPACITY_MULTI_MAP = 10;
    static constexpr double MAX_LOAD_FACTOR = 0.75;
    static constexpr double MIN_LOAD_FACTOR = 0.25;
    Node** table;
    int capacity;
    int length;
    // Hash function
    int hash(const int& key, int capacity) const;

    // Helper methods for resizing the hash table
    void resize();
    void rehash();

    // Helper method to find a node in the linked list for a given key
    Node* findNode(const int key) const;

public:
	//constructor
	MultiMap();

    void increaseCapacity(Node* node);
    void sizeDown();

	//adds a key value pair to the multimap
	void add(TKey c, TValue v);

	//removes a key value pair from the multimap
	//returns true if the pair was removed (if it was in the multimap) and false otherwise
	bool remove(TKey c, TValue v);

	//returns the vector of values associated to a key. If the key is not in the MultiMap, the vector is empty
	vector<TValue> search(TKey c) const;

	//returns the number of pairs from the multimap
	int size() const;

	//checks whether the multimap is empty
	bool isEmpty() const;

	//returns an iterator for the multimap
    MultiMapIterator iterator();
    MultiMapKeyIterator keyiterator();

	//descturctor
	~MultiMap();


};

