#include "MultiMap.h"
#include "MultiMapIterator.h"
#include "MultiMapKeyIterator.h"
#include <exception>
#include <iostream>

using namespace std;

//Best: Teta(node->amount)
//Average: Teta(node->amount)
//Worst: Teta(node->amount)
void MultiMap::increaseCapacity(Node *node) {
    // Calculate the new capacity
    int newCapacity = node->amount  * 2;

    // Create a new array with the new capacity
    TValue *newValues = new TValue[newCapacity];

    // Copy the existing values to the new array
    for (int i = 0; i < node->amount; i++) {
        newValues[i] = node->values[i];
    }
    for (int i = node->amount; i < newCapacity; i++) {
        newValues[i] = NULL_TVALUE;
    }
    // Delete the old array and assign the new array to the node
    delete[] node->values;
    node->values = newValues;
}

// Hash function
//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
int MultiMap::hash(const int& key, int capacity_) const {
    return abs(key) % capacity_;
}

// Helper method for resizing the hash table
//Best: Teta(n)/Teta(capacity * k)
//Average: Teta(n)/Teta(capacity * k)
//Worst: Teta(n)/Teta(capacity * k)  n= number of key-value pairs k=the average number of nodes in each linked list
void MultiMap::resize() {
    int newCapacity = capacity * 2;
    Node **newTable = new Node *[newCapacity]{};

    // Rehash all key-value pairs into the new table
    for (int i = 0; i < capacity; i++) {
        Node *current = table[i];
        while (current != nullptr) {
            Node *next = current->next;
            int index = hash(current->key,newCapacity); // Use newCapacity for index calculation
            current->next = newTable[index];
            newTable[index] = current;
            current = next;
        }
    }
    // Free the memory allocated for the old table
    delete[] table;

    // Update the table and capacity to the new values
    table = newTable;
    capacity = newCapacity;
}


// Helper method for rehashing a single key-value pair
//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(resize) wenn es resize appeliert
void MultiMap::rehash() {
    // Check if resizing is needed
    if (length >= capacity * MAX_LOAD_FACTOR) {
        resize();
    }
}

//Best: Teta(capacity)
//Average: Teta(capacity)
//Worst: Teta(capacity)
MultiMap::MultiMap() {
    // Constructor
    // Initialize the hash table with null pointers
    capacity = INITIAL_CAPACITY;
    length = 0;
    table = new Node *[capacity]();
    for (int i = 0; i < capacity; i++) {
        table[i] = nullptr;
    }
}

//In the MultiMap ADT, each key can have multiple associated values. So, you are allowed to have multiple keys with the same value in the MultiMap. The purpose of the MultiMap is to store key-value pairs, where a key can have multiple associated values.
//Each key can also have duplicate values
//Best Case: Teta(1)
//Average Case: Teta(n), where n is the average number of elements in each bucket
//Worst Case: Teta(n), where n is the number of elements in the bucket with the maximum number of elements
void MultiMap::add(TKey c, TValue v) {
    int index = hash(c,capacity);
    Node *currentNode = table[index];
    Node *previousNode = nullptr;

    while (currentNode != nullptr && currentNode->key != c) {
        previousNode = currentNode;
        currentNode = currentNode->next;
    }

    if (currentNode != nullptr && currentNode->key == c) {
        // The key already exists
        if (currentNode->amount >= currentNode->capacityNode) {
            // Increase the capacity of the value array
            increaseCapacity(currentNode);
        }
        // Add the value to the existing node
        currentNode->values[currentNode->amount] = v;
        currentNode->amount++;
    } else {
        // Create a new node and add it to the table
        Node *newNode = new Node;
        newNode->key = c;
        newNode->values = new TValue[newNode->capacityNode]{NULL_TVALUE}; // Create a new array with 5 elements
        newNode->values[newNode->amount] = v; // Assign the value to the first element
        newNode->amount++;
        newNode->next = nullptr;

        if (previousNode == nullptr) {
            table[index] = newNode;
        } else {
            previousNode->next = newNode;
        }
    }
    length++;
    rehash(); //check if rehash/size is needed
}

//Best Case: Teta(1)
//Average Case: Teta(n), where n is the average number of elements in each bucket
//Worst Case: Teta(n), where n is the number of elements in the bucket with the maximum number of elements
bool MultiMap::remove(TKey c, TValue v) {
    if (length == 0) {
        return false;
    }

    int index = hash(c,capacity);
    Node *currentNode = table[index];
    Node *previousNode = nullptr;

    while (currentNode != nullptr) {
        if (currentNode->key == c) {
            // Find the index of the value to remove
            int valueIndex = -1;
            for (int i = 0; i < currentNode->amount; i++) {
                if (currentNode->values[i] == v) {
                    valueIndex = i;
                    break;
                }
            }

            if (valueIndex != -1) {
                // Shift values to the left to overwrite the value to be removed
                for (int i = valueIndex; i < currentNode->amount - 1; i++) {
                    currentNode->values[i] = currentNode->values[i + 1];
                }

                currentNode->amount--;

                if (currentNode->amount == 0) {
                    // The last value was removed, delete the node
                    if (previousNode == nullptr) {
                        table[index] = currentNode->next;
                    } else {
                        previousNode->next = currentNode->next;
                    }
                    delete[] currentNode->values;
                    delete currentNode;
                    currentNode = nullptr; // Set currentNode to nullptr after deletion
                }

                length--;

//                 Check if length is 0
//                if (length == 0) {
//                    // Reset the values and delete the old table
//                    for (int i = 0; i < capacity; i++) {
//                        Node *node = table[i];
//                        while (node != nullptr) {
//                            Node *nextNode = node->next;
//                            delete[] node->values;
//                            delete node;
//                            node = nextNode;
//                        }
//                        table[i] = nullptr;
//                    }
//                    delete[] table;
//                    table = nullptr;
//                    capacity = INITIAL_CAPACITY;
//                }
//                else {
//                    // Check if resizing down is needed
//                    sizeDown();
//                }

                rehash();
                return true;
            }
        }

        previousNode = currentNode;
        currentNode = currentNode->next;
    }
    return false; // Key-value pair was not found
}

//void MultiMap::sizeDown() {
//    // Check if resizing down is needed
//    int newCapacity = capacity / 2;
//
//    if (length <= newCapacity * MIN_LOAD_FACTOR) {
//        Node **newTable = new Node *[newCapacity]{};
//
//        // Rehash all key-value pairs into the new table
//        for (int i = 0; i < capacity; i++) {
//            Node *current = table[i];
//            while (current != nullptr) {
//                Node *next = current->next;
//                int index = hash(current->key,newCapacity); // Use newCapacity for index calculation
//                current->next = newTable[index];
//                newTable[index] = current;
//                current = next;
//            }
//        }
//
//        // Free the memory allocated for the old table
//        delete[] table;
//
//        // Update the table and capacity to the new values
//        table = newTable;
//        capacity = newCapacity;
//    }
//}

//Best Case: Teta(1)
//Average Case: Teta(n), where n is the average number of elements in each bucket
//Worst Case: Teta(n), where n is the number of elements in the bucket with the maximum number of elements
vector<TValue> MultiMap::search(TKey c) const {
    vector<TValue> result{};
    int index = hash(c,capacity);
    Node *currentNode = table[index];

    while (currentNode != nullptr) {
        if (currentNode->key == c) {
            for (int i = 0; i < currentNode->amount; i++) {
                result.push_back(currentNode->values[i]);
            }
        }
        currentNode = currentNode->next;
    }

    return result;
}

//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
int MultiMap::size() const {
    return length;
}

//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
bool MultiMap::isEmpty() const {
    return length == 0;
}

//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
MultiMapIterator MultiMap::iterator() {
    return MultiMapIterator(*this);
}
//Best: Teta(1)
//Average: Teta(1)
//Worst: Teta(1)
MultiMapKeyIterator MultiMap::keyiterator() {
    return MultiMapKeyIterator(*this);
}


//Best: Teta(capacity)
//Average: Teta(capacity)
//Worst: Teta(capacity)
MultiMap::~MultiMap() {
    for (int i = 0; i < capacity; i++) {
        Node *currentNode = table[i];
        while (currentNode != nullptr) {
            Node *nextNode = currentNode->next;
            delete[] currentNode->values;
            delete currentNode;
            currentNode = nextNode;
        }
    }
    delete[] table;
}