#pragma once
#include <stdexcept>
#include "MultiMapKeyIterator.h"
#include "MultiMap.h"


class MultiMap;

class MultiMapKeyIterator
{
    friend class MultiMap;

private:
    const MultiMap& col;
    int currentBucket;
    int pos;
    Node* currentNode;
    MultiMapKeyIterator(const MultiMap& c);
public:
    void nextKey();
    int getCurrent()const;
    bool valid() const;
    void first();

};