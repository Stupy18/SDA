#include <iostream>
#include <cassert>
#include "MultiMap.h"
#include "ExtendedTest.h"
#include "ShortTest.h"
#include "MultiMapIterator.h"
#include "MultiMapKeyIterator.h"

using namespace std;

void testKeyIterator() {
    MultiMap multiMap;

    // Add some key-value pairs
    multiMap.add(1, 20);
    multiMap.add(2, 30);
    multiMap.add(3, 40);
    multiMap.add(3, 50);
    multiMap.add(3, 60);
    MultiMapKeyIterator keyiterator = multiMap.keyiterator();
    keyiterator.first();
    assert(keyiterator.getCurrent()==1);
    keyiterator.nextKey();
    keyiterator.first();
    assert(keyiterator.getCurrent()==1);
}

int main() {

    testKeyIterator();
	testAll();
	testAllExtended();
	cout << "End" << endl;
	system("pause");

}
