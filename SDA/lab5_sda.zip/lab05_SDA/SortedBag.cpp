#include "SortedBag.h"
#include "SortedBagIterator.h"

SortedBag::SortedBag(Relation r) {
    capacity = 16;
    nodes = new Node[capacity];
    root = -1;
    firstEmpty = 0;
    length = 0;
    relation = r;
    for (int i = 0; i < capacity - 1; i++) {
        nodes[i].next_right = i + 1;
        nodes[i].next_left = i + 1;
    }
    nodes[capacity - 1].next_right = -1;
    nodes[capacity - 1].next_left = -1;
}

void SortedBag::resize() {
    capacity *= 2; // double the capacity
    Node* newNodes = new Node[capacity];
    for (int i = 0; i < length; i++) {
        newNodes[i] = nodes[i]; // copy existing elements
    }
    for (int i = length; i < capacity - 1; i++) {
        newNodes[i].next_right = i + 1;
        newNodes[i].next_left = i + 1;  // link remaining nodes as a singly linked list
    }
    newNodes[capacity - 1].next_right = -1;
    newNodes[capacity - 1].next_left = -1; // last node points to -1 to indicate the end of the list
    delete[] nodes; // deallocate old memory
    nodes = newNodes; // update the nodes pointer to point to the new array
    firstEmpty = length; // update the firstEmpty index
}

void SortedBag::add(TElem e) {
    if (length == capacity) {
        resize(); // resize the array if it's full
    }

    int currentNode = root;
    int parentNode = -1;

    // Find the correct position to insert the new element
    while (currentNode != -1 && nodes[currentNode].element != e) {
        parentNode = currentNode;
        if (relation(e, nodes[currentNode].element)) {
            currentNode = nodes[currentNode].next_left;
        } else {
            currentNode = nodes[currentNode].next_right;
        }
    }

    if (currentNode != -1) {
        // The element already exists in the bag, increment its frequency
        nodes[currentNode].frequency++;
    } else {
        // Insert a new node with the element
        int newPosition;
        if (firstEmpty != -1) {
            // Reuse a free position from the stack
            newPosition = firstEmpty;
            firstEmpty = nodes[firstEmpty].next_left;
        } else {
            // No free positions available, assign a new position
            newPosition = length;
        }

        nodes[newPosition].element = e;
        nodes[newPosition].frequency = 1;
        nodes[newPosition].next_left = -1;
        nodes[newPosition].next_right = -1;

        if (parentNode == -1) {
            // The tree is empty, make the new node the root
            root = newPosition;
        } else if (relation(e, nodes[parentNode].element)) {
            // Insert the new node as the left child of the parent
            nodes[newPosition].next_right = parentNode;
            nodes[parentNode].next_left = newPosition;
        } else {
            // Insert the new node as the right child of the parent
            nodes[newPosition].next_right = nodes[parentNode].next_right;
            nodes[parentNode].next_right = newPosition;
        }
    }

    length++;
}

void SortedBag::size_down() {
    int newCapacity = capacity / 2;
    if (newCapacity < 10 || length > newCapacity) {
        return;
    }

    Node* newArray = new Node[newCapacity];

    // Copy the old elements to the new array
    int index = root;
    for (int i = 0; i < length; i++) {
        newArray[i].element = nodes[index].element;
        newArray[i].frequency = nodes[index].frequency;
        newArray[i].next_left = i - 1;
        newArray[i].next_right = i + 1;
        index = nodes[index].next_right;
    }

    // Set the next pointers of the first and last nodes in the array
    newArray[0].next_left = -1;
    newArray[length - 1].next_right = -1;

    // Update the variables of the sorted bag
    delete[] nodes;
    nodes = newArray;
    firstEmpty = length;
    capacity = newCapacity;

    // Update the root pointer
    root = 0;
}

bool SortedBag::remove(TComp e) {
    if (length == 0) {
        return false;
    }

    int currentNode = root;
    int parentNode = -1;

    // Find the node with the element
    while (currentNode != -1 && nodes[currentNode].element != e) {
        parentNode = currentNode;
        if (relation(e, nodes[currentNode].element)) {
            currentNode = nodes[currentNode].next_left;
        } else {
            currentNode = nodes[currentNode].next_right;
        }
    }

    if (currentNode != -1) {
        if (nodes[currentNode].frequency > 1) {
            // Decrease the frequency of the element
            nodes[currentNode].frequency--;
        } else {
            // Remove the node
            if (parentNode == -1) {
                // The root is being removed
                root = nodes[root].next_right;
            } else if (relation(e, nodes[parentNode].element)) {
                // The node to remove is the left child of the parent
                nodes[parentNode].next_left = nodes[currentNode].next_right;
            } else {
                // The node to remove is the right child of the parent
                nodes[parentNode].next_right = nodes[currentNode].next_right;
            }

            // Add the removed node to the free positions list
            nodes[currentNode].next_right = firstEmpty;
            firstEmpty = currentNode;
        }

        length--;

        if (length == 0) {
            // If the bag is now empty, reset the head and firstEmpty pointers
            root = -1;
            firstEmpty = 0;
            capacity = 16;
            delete[] nodes;
            nodes = new Node[capacity];
            for (int i = 0; i < capacity - 1; i++) {
                nodes[i].next_right = i + 1;
                nodes[i].next_left = i + 1;
            }
            nodes[capacity - 1].next_right = -1;
            nodes[capacity - 1].next_left = -1;
        } else if (length <= capacity / 4) {
            size_down();
        }

        return true;
    }

    return false;
}

bool SortedBag::search(TComp e) const {
    int currentNode = root;

    // Traverse the tree to find the node with the element
    while (currentNode != -1 && nodes[currentNode].element != e) {
        if (relation(e, nodes[currentNode].element)) {
            currentNode = nodes[currentNode].next_left;
        } else {
            currentNode = nodes[currentNode].next_right;
        }
    }

    if (currentNode != -1) {
        return true;
    }

    return false;
}

int SortedBag::nrOccurrences(TComp e) const {
    int currentNode = root;

    // Traverse the tree to find the node with the element
    while (currentNode != -1 && nodes[currentNode].element != e) {
        if (relation(e, nodes[currentNode].element)) {
            currentNode = nodes[currentNode].next_left;
        } else {
            currentNode = nodes[currentNode].next_right;
        }
    }

    if (currentNode != -1) {
        return nodes[currentNode].frequency;
    }

    return 0;
}

bool SortedBag::isEmpty() const {
    return length == 0;
}

int SortedBag::size() const {
    return length;
}

SortedBagIterator SortedBag::iterator() const {
    return SortedBagIterator(*this);
}

SortedBag::~SortedBag() {
    delete[] nodes;
}