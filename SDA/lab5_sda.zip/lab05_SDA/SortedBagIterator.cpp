#include <exception>
#include "SortedBagIterator.h"

// Constructor
SortedBagIterator::SortedBagIterator(const SortedBag& b) : bag(b) {
    first();
}

// getCurrent method
TComp SortedBagIterator::getCurrent() {
    if (!valid()) {
        throw std::exception();;
    }

    return bag.nodes[currentNode].element;
}

// valid method
bool SortedBagIterator::valid() {
    return currentNode != -1;
}

// next method
void SortedBagIterator::next() {
    if (!valid()) {
        throw std::exception();
    }

    if (bag.nodes[currentNode].frequency > currentFrequency + 1) {
        currentFrequency++;
    }
    else {
        currentNode = bag.nodes[currentNode].next_right;
        currentFrequency = 0;
    }
}

// first method
void SortedBagIterator::first() {
    currentNode = bag.root;
    currentFrequency = 0;
}