#pragma once

void testAllExtended();