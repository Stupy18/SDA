#include "SortedBag.h"
#include "SortedBagIterator.h"

SortedBag::SortedBag(Relation r) {
    capacity = 10;
    nodes = new Node[capacity];
    root = -1;
    firstEmpty = 0;
    length = 0;
    relation = r;
    for (int i = 0; i < capacity - 1; i++)
        nodes[i].next_right = i + 1;
    nodes[capacity - 1].next_right = -1;
}

void SortedBag::resize() {
    capacity *= 2; // double the capacity
    Node* newNodes = new Node[capacity];
    for (int i = 0; i < length; i++) {
        newNodes[i] = nodes[i]; // copy existing elements
    }
    for (int i = length; i < capacity - 1; i++) {
        newNodes[i].next_right = i + 1; // link remaining nodes as a singly linked list
    }
    newNodes[capacity - 1].next_right = -1; // last node points to -1 to indicate the end of the list
    delete[] nodes; // deallocate old memory
    nodes = newNodes; // update the nodes pointer to point to the new array
}

void SortedBag::add(TComp e) {
    if (length == capacity) {
        resize(); // resize the array if it's full
    }

    int currentNode = root;
    int parentNode = -1;

    // Find the correct position to insert the new element
    while (currentNode != -1 && nodes[currentNode].element != e) {
        parentNode = currentNode;
        if (relation(e, nodes[currentNode].element)) {
            currentNode = nodes[currentNode].next_left;
        } else {
            currentNode = nodes[currentNode].next_right;
        }
    }

    if (currentNode != -1) {
        // The element already exists in the bag, increment its frequency
        nodes[currentNode].frequency++;
    } else {
        // Insert a new node with the element
        int newPosition = firstEmpty;
        firstEmpty = nodes[firstEmpty].next_right;
        nodes[newPosition].element = e;
        nodes[newPosition].frequency = 1;
        nodes[newPosition].next_left = -1;
        nodes[newPosition].next_right = -1;

        if (parentNode == -1) {
            // The tree is empty, make the new node the root
            root = newPosition;
        } else if (relation(e, nodes[parentNode].element)) {
            // Insert the new node as the left child of the parent
            nodes[newPosition].next_right = parentNode;
            nodes[parentNode].next_left = newPosition;
        } else {
            // Insert the new node as the right child of the parent
            nodes[newPosition].next_right = nodes[parentNode].next_right;
            nodes[parentNode].next_right = newPosition;
        }

        length++;
    }
}


bool SortedBag::remove(TComp e) {
    int currentNode = root;
    int parentNode = -1;

    // Find the node with the element
    while (currentNode != -1 && nodes[currentNode].element != e) {
        parentNode = currentNode;
        if (relation(e, nodes[currentNode].element)) {
            currentNode = nodes[currentNode].next_left;
        } else {
            currentNode = nodes[currentNode].next_right;
        }
    }

    if (currentNode != -1) {
        if (nodes[currentNode].frequency > 1) {
            // Decrease the frequency of the element
            nodes[currentNode].frequency--;
        } else {
            // Remove the node
            if (parentNode == -1) {
                // The root is being removed
                root = nodes[root].next_right;
            } else if (relation(e, nodes[parentNode].element)) {
                // The node to remove is the left child of the parent
                nodes[parentNode].next_left = nodes[currentNode].next_right;
            } else {
                // The node to remove is the right child of the parent
                nodes[parentNode].next_right = nodes[currentNode].next_right;
            }

            // Add the removed node to the free positions list
            nodes[currentNode].next_right = firstEmpty;
            firstEmpty = currentNode;

            length--;
        }

        return true;
    }

    return false;
}


bool SortedBag::search(TComp e) const {
    int currentNode = root;

    // Traverse the tree to find the node with the element
    while (currentNode != -1 && nodes[currentNode].element != e) {
        if (relation(e, nodes[currentNode].element)) {
            currentNode = nodes[currentNode].next_left;
        } else {
            currentNode = nodes[currentNode].next_right;
        }
    }

    if (currentNode != -1) {
        return true;
    }

    return false;
}



int SortedBag::nrOccurrences(TComp e) const {
    int currentNode = root;

    // Traverse the tree to find the node with the element
    while (currentNode != -1 && nodes[currentNode].element != e) {
        if (relation(e, nodes[currentNode].element)) {
            currentNode = nodes[currentNode].next_left;
        } else {
            currentNode = nodes[currentNode].next_right;
        }
    }

    if (currentNode != -1) {
        return nodes[currentNode].frequency;
    }

    return 0;
}



bool SortedBag::isEmpty() const {
    return length == 0;
}

int SortedBag::size() const {
    return length;
}


SortedBagIterator SortedBag::iterator() const {
	return SortedBagIterator(*this);
}


SortedBag::~SortedBag() {
    delete[] nodes;
}
