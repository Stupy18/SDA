#include "SortedBagIterator.h"
#include "SortedBag.h"
#include <exception>

using namespace std;

SortedBagIterator::SortedBagIterator(const SortedBag& b) : bag(b) {
    // Initialize the iterator
    currentFrequency = 0;
    currentNode = b.root;
}

TComp SortedBagIterator::getCurrent() {
    if (!valid()) {
        throw std::exception();
    }

    // Return the element of the current node
    return bag.nodes[currentNode].element;
}

bool SortedBagIterator::valid() {
    // Check if the iterator is valid (i.e., not at the end of the bag)
    return currentNode != -1;
}

void SortedBagIterator::next() {
    if (!valid()) {
        throw std::exception();
    }

    if (currentFrequency < bag.nodes[currentNode].frequency - 1) {
        // Move to the next occurrence of the current element
        currentFrequency++;
    } else {
        // Move to the next node in the BST
        currentNode = bag.nodes[currentNode].next_right;
        currentFrequency = 0;
    }
}

void SortedBagIterator::first() {
    // Reset the iterator to the beginning of the bag
    currentNode = bag.root;
    currentFrequency = 0;
}

