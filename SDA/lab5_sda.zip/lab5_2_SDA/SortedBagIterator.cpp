#include <stdexcept>
#include "SortedBagIterator.h"

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(log n)
SortedBagIterator::SortedBagIterator(const SortedBag& sb) : sb(sb), currentNode(-1), stackSize(0), stack(nullptr) {
    resizeStack(10); // Initial capacity of the stack
    first();
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
SortedBagIterator::~SortedBagIterator() {
    delete[] stack;
}

//Best Case: Teta(stacksize)
//Average Case: Teta(stacksize)
//Worst Case: Teta(stacksize)
void SortedBagIterator::resizeStack(int capacity) {
    int* newStack = new int[capacity];
    for (int i = 0; i < stackSize; i++) {
        newStack[i] = stack[i];
    }
    delete[] stack;
    stack = newStack;
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(stacksize)
void SortedBagIterator::push(int value) {
    if (stackSize == 0) {
        resizeStack(10);
    }
    else if (stackSize % 10 == 0) {
        resizeStack(stackSize + 10);
    }
    stack[stackSize++] = value;
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
int SortedBagIterator::pop() {
    if (stackSize == 0) {
        throw std::runtime_error{ "Stack is empty" };
    }
    return stack[--stackSize];
}

//Best Case: Teta(log n)
//Average Case: Teta(log n)
//Worst Case: Teta(log n)
void SortedBagIterator::first() {
    currentNode = sb.root;
    stackSize = 0;

    while (currentNode != -1) {
        push(currentNode);
        currentNode = sb.tree[currentNode].getLeftSon();
    }

    if (stackSize > 0) {
        currentNode = stack[stackSize - 1];
    }
    else {
        currentNode = -1;
    }
}

// in order non recursive method
//Best Case: Teta(log n)
//Average Case: Teta(log n)
//Worst Case: Teta(log n)
void SortedBagIterator::next() {
    if (!valid()) {
        throw std::runtime_error{ "Iterator is not valid" };
    }

    int node = pop();

    if (sb.tree[node].getRightSon() != -1) {
        node = sb.tree[node].getRightSon();
        while (node != -1) {
            push(node);
            node = sb.tree[node].getLeftSon();
        }
    }

    if (stackSize > 0) {
        currentNode = stack[stackSize - 1];
    }
    else {
        currentNode = -1;
    }
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
bool SortedBagIterator::valid() const {
    return currentNode != -1;
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
TComp SortedBagIterator::getCurrent() const {
    if (!valid()) {
        throw std::runtime_error{ "Iterator is not valid" };
    }
    return sb.tree[currentNode].getValue();
}