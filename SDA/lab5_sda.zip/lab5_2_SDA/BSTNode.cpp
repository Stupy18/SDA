
#include "BSTNode.h"

TComp BSTNode::getValue() const {
    return value;
}

void BSTNode::setValue(TComp value) {
    this->value = value;
}

int BSTNode::getLeftSon() const {
    return leftSon;
}

void BSTNode::setLeftSon(int leftSon) {
    this->leftSon = leftSon;
}

int BSTNode::getRightSon() const {
    return rightSon;
}

void BSTNode::setRightSon(int rightSon) {
    this->rightSon = rightSon;
}

BSTNode::BSTNode(TComp value, int leftSon, int rightSon) : value(NULL_TElem), leftSon(leftSon), rightSon(rightSon) {}

bool BSTNode::isNull() {
    return value == NULL_TElem;
}

bool BSTNode::isLeaf() {
    return leftSon == -1 && rightSon == -1;
}
