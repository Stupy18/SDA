#include <iostream>
#include "ShortTest.h"
#include "ExtendedTest.h"

int main() {
    testAll();
    testAllExtended();
    return 0;
}