#pragma once
#include "SortedBag.h"

class SortedBag;
typedef int TComp;

class SortedBagIterator {
    friend class SortedBag;

private:
    const SortedBag& sb;
    int currentNode;
    int currentFrequency;
    int stackSize;
    int* stack;

    void resizeStack(int capacity);
    void push(int value);
    int pop();

public:
    SortedBagIterator(const SortedBag& sb);
    ~SortedBagIterator();
    void first();
    void next();
    bool valid() const;
    TComp getCurrent() const;
};