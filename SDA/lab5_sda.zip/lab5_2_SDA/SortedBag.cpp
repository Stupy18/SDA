#include "SortedBag.h"
#include "BSTNode.h"
#include <iostream>
SortedBag::SortedBag(Relation r): root{-1},
                                  numberOfElements{0},
                                  capacity{16},
                                  firstFree{0},
                                  r{r}
{
    tree = new BSTNode[16];
}

//pre:s Sortedbag(this),t Sortedbag(other)
//post:true wenn sie gleich sind, false wenn nicht


//Best Case: Teta(n)
//Average Case: Teta(n)
//Worst Case: Teta(n)


//pseudocod:
// isSame(other):boolean
//Wenn this.countOfElements != other.countOfElements
//  false;
//isSameRecursive(this.root,other.root,other.tree)

//isSameRecursive(this.root,other.root,other.tree):boolean
//Wenn node1 gleich -1 und node2 gleich -1 dann
// Wenn das Ende beider Bäume erreicht ist, sind alle Knoten gleich
//      wahr
//        Sonst wenn node1 ungleich -1 und node2 ungleich -1 dann
// Beide Knoten existieren, vergleiche ihre Werte
//Wenn tree[node1].value != otherTree[node2].value dann
//      falsch
//
// Überprüfe rekursiv die linken und rechten Teilbäume
//linksGleich := isSameRecursive(tree[node1].leftSon, otherTree[node2].leftSon, otherTree)
//rechtsGleich := isSameRecursive(tree[node1].rightSon, otherTree[node2].rightSon, otherTree)
//
//  wahr, wenn beide Teilbäume gleich sind
//      links & rechts
//
// Ein Knoten existiert und der andere ist null, Behälter sind nicht gleich
//      falsch
bool SortedBag::isSame(const SortedBag& other) const {
    if (numberOfElements != other.numberOfElements) {
        // If the number of elements is different, the containers are not the same
        return false;
    }

    // Traverse the tree and compare the values of corresponding nodes
    return isSameRecursive(root, other.root, other.tree);
}

bool SortedBag::isSameRecursive(int node1, int node2, const BSTNode* otherTree) const {
    if (node1 == -1 && node2 == -1) {
        // Reached the end of both trees, all nodes are the same
        return true;
    } else if (node1 != -1 && node2 != -1) {
        // Both nodes exist, compare their values
        if (tree[node1].getValue() != otherTree[node2].getValue()) {
            // Values are different, containers are not the same
            return false;
        }

        // Recursively check the left and right subtrees
        bool leftSame = isSameRecursive(tree[node1].getLeftSon(), otherTree[node2].getLeftSon(), otherTree);
        bool rightSame = isSameRecursive(tree[node1].getRightSon(), otherTree[node2].getRightSon(), otherTree);

        // Return true if both subtrees are the same
        return leftSame && rightSame;
    } else {
        // One node exists and the other is null, containers are not the same
        return false;
    }
}

//Best Case: Teta(1)
//Average Case: Teta(log n)
//Worst Case: Teta(n) - degenerat
void SortedBag::add(TComp e) {
    if (mustBeResized()) { // daca trebuie sa redimensionam vectorul, o facem
        resize();
    }

    // nodul nou adaugat o sa fie pe pozitia firstFree, asa ca-l adaugam de pe acuma
    tree[firstFree].setValue(e);
    tree[firstFree].setLeftSon(-1);
    tree[firstFree].setRightSon(-1);

    // caut pozitia pe care trebuie sa adaug nodul
    // la final o sa fie "parent"
    int current = root, parent = -1;
    while (current != -1) {
        parent = current;
        if (r(e, tree[current].getValue())) // daca relatia dintre elementu pe care trebe sa-l bag si valoarea in arbore se satisface
            // atunci trebuie sa ma duc pe fiul stang
            current = tree[current].getLeftSon();
        else                                // altfel ma duc pe fiul drept
            current = tree[current].getRightSon();
    }


    if (root == -1) // caz particular - nu avem radacina => radacina este firstFree
        root = firstFree;
    else if (r(e, tree[parent].getValue())) // daca trebuie sa pun elementul pe fiul stang, il pun pe fiul stang
        tree[parent].setLeftSon(firstFree);
    else                                    // altfel, pe fiul drept
        tree[parent].setRightSon(firstFree);
    changeFirstFree(); // actualizam firstFree
    ++numberOfElements; // crestem nr. de elemente
}

void SortedBag::changeFirstFree() {
    ++firstFree;
    while (firstFree < capacity && !tree[firstFree].isNull())
        ++firstFree;
}

//Best Case: Teta(1)
//Average Case: Teta(log n)
//Worst Case: Teta(n) - degenerat
bool SortedBag::remove(TComp e) {
    bool removed = false; // daca l-am sters sau nu, o sa se actualizeze in functia removeRecursively
    root = removeRecursively(root, e, removed);
    if (removed)
        --numberOfElements;
    return removed;
}

//Best Case: Teta(1)
//Average Case: Teta(log n)
//Worst Case: Teta(n) - degenerat
bool SortedBag::search(TComp e) const {
    int currentNode = root;

    // ma duc pe fiul stang sau drept in functie de cum se stabileste relatia
    while (currentNode != -1) {
        if (tree[currentNode].getValue() == e)
            return true;
        if (r(e, tree[currentNode].getValue())) {
            currentNode = tree[currentNode].getLeftSon();
        }
        else {
            currentNode = tree[currentNode].getRightSon();
        }
    }
    return false;
}

//Best Case: Teta(1)
//Average Case: Teta(log n)
//Worst Case: Teta(n) - degenerat
int SortedBag::nrOccurrences(TComp e) const {
    int currentNode = root;
    int counter = 0;

    // la fel ca la search
    while (currentNode != -1) {
        if (tree[currentNode].getValue() == e)
            ++counter;
        if (r(e, tree[currentNode].getValue())) {
            currentNode = tree[currentNode].getLeftSon();
        }
        else {
            currentNode = tree[currentNode].getRightSon();
        }
    }
    return counter;
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
int SortedBag::size() const {
    return numberOfElements;
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
SortedBagIterator SortedBag::iterator() const {
    return SortedBagIterator(*this);
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
bool SortedBag::isEmpty() const {
    return numberOfElements == 0;
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
SortedBag::~SortedBag() {
    delete[] tree;
}

//Best Case: Teta(1)
//Average Case: Teta(1)
//Worst Case: Teta(1)
bool SortedBag::mustBeResized() {
    return firstFree >= capacity;
}

//Best Case: Teta(capacity)
//Average Case: Teta(capacity)
//Worst Case: Teta(capacity)
void SortedBag::resize() {
    BSTNode *newTree = new BSTNode[capacity * 2];
    for (int i = 0; i < capacity; ++i) {
        newTree[i].setValue(tree[i].getValue());
        newTree[i].setLeftSon(tree[i].getLeftSon());
        newTree[i].setRightSon(tree[i].getRightSon());
    }
    delete[] tree;
    tree = newTree;
    firstFree = capacity;
    capacity *= 2;
}

//Best Case: Teta(log n)
//Average Case:Teta(log n)
//Worst Case: Teta(log n)
TComp SortedBag::getMinimum(int startingRoot) {
    int currentNode = startingRoot, minNode = startingRoot;
    TComp minimum;

    // caut cel mai mic element din subarborele BSB cu radacina in startingRoot
    // asta inseamna cel mai din stanga nod, adica ma duc cat de tare pot in stanga
    // o sa se afle in minNode
    while (currentNode != -1) {
        minimum = tree[currentNode].getValue();
        minNode = currentNode;
        currentNode = tree[currentNode].getLeftSon();
    }
    return minNode;
}

//Best Case: Teta(log n)
//Average Case:Teta(log n)
//Worst Case: Teta(log n)
TComp SortedBag::getMaximum(int startingRoot) {
    int currentNode = startingRoot, maxNode = startingRoot;
    TComp maximum;

    // caut cel mai mare element din subarborele BSB cu radacina in startingRoot
    // asta inseamna cel mai din dreapta nod, adica ma duc cat de tare pot in dreapta
    // o sa se afle in maxNode
    while (currentNode != -1) {
        maximum = tree[currentNode].getValue();
        maxNode = currentNode;
        currentNode = tree[currentNode].getRightSon();
    }
    return maxNode;
}

//Best Case: Teta(1)
//Average Case:Teta(log n)
//Worst Case: Teta(n)
int SortedBag::removeRecursively(int node, TComp e, bool &removed) {
    if (node == -1)
        return node;

    if (e == tree[node].getValue()) {
        // am dat de elementul pe care-l caut, trebe sa-l sterg
        removed = true;
        if (tree[node].getLeftSon() == -1) { // daca nu exista un fiu stang, inseamna ca mutam subarborele care incepe
            // in fiul drept peste subarborele determinat de "node"
            int rightSon = tree[node].getRightSon();
//            tree[node] = BSTNode{NULL_TElem, -1, -1};
            return rightSon;
        }
        else if (tree[node].getRightSon() == -1) { // analog ca mai sus, doar ca pt fiul drept, mutam subarborele
            // care incepe in fiul stang
            int leftSon = tree[node].getLeftSon();
//            tree[node] = BSTNode{NULL_TElem, -1, -1};
            return leftSon;
        }

        // altfel daca are ambii fii, punem valoarea celui mai mare element din subarborele stang
        // cu valoarea din nodul si stergem o aparitie a celui mai mare element (ca sa nu apara de 2 ori, ca e ca si
        // cum l-am muta pe ala in nodul curent
        int maxNode = getMaximum(tree[node].getLeftSon());
        tree[node].setValue(tree[maxNode].getValue());
        tree[node].setLeftSon(removeRecursively(tree[node].getLeftSon(), tree[maxNode].getValue(), removed));
    }
    else if (r(e, tree[node].getValue())) {
        // daca nodul se afla in subarborele determinat de fiul stang, atunci
        // fiul stang va fi radacina subarborelui determinat de initialul fiu stang dupa ce elementul cautat
        // a fost sters
        tree[node].setLeftSon(removeRecursively(tree[node].getLeftSon(), e, removed));
    }
    else {
        // la fel, doar ca pt fiul drept
        tree[node].setRightSon(removeRecursively(tree[node].getRightSon(), e, removed));
    }
    return node;
}