#include "Set.h"
#include "SetIterator.h"
#include "ExtendedTest.h"
#include "ShortTest.h"
#include <stack>
#include <iostream>
#include <cassert>
using namespace std;

void test_reverse() {
    Set s;
    assert(s.isEmpty() == true);
    assert(s.size() == 0);
    assert(s.add(5) == true);
    assert(s.add(1) == true);
    assert(s.add(10) == true);
    assert(s.add(7) == true);
    assert(s.add(1) == false);
    assert(s.add(10) == false);
    assert(s.add(-3) == true);
    assert(s.size() == 5);
    s.print();
    s.reverse();
    assert(!s.isEmpty());
    s.print();
}



int main() {

	testAll();
	testAllExtended();
    test_reverse();
	cout << "That's all!" << endl;
	system("pause");

}



