#pragma once
//DO NOT INCLUDE SETITERATOR

//DO NOT CHANGE THIS PART
#define NULL_TELEM -111111
typedef int TElem;
class SetIterator;

struct Node {
    TElem data;
    int next;
};

class Set {
	//DO NOT CHANGE THIS PART
	friend class SetIterator;

    private:

    Node *array; // Array von Knoten
    int capacity; // Maximale Kapazität des Arrays
    int head; // Index des ersten Elements in der Liste
    int length; // Anzahl der Elemente im Set
    int firstEmpty;

    public:
        //implicit constructor
        Set();

        //adds an element to the set
		//returns true if the element was added, false otherwise (if the element was already in the set and it was not added)
        bool add(TElem e);


        //resizer
        void resize();

        //resizer_down
        void size_down();

        //removes an element from the set
		//returns true if e was removed, false otherwise
        bool remove(TElem e);

        //checks whether an element belongs to the set or not
        bool search(TElem elem) const;

        //returns the number of elements;
        int size() const;

        //check whether the set is empty or not;
        bool isEmpty() const;

        //return an iterator for the set
        SetIterator iterator() const;

        // destructor
        ~Set();

        void reverse();

        void print() const;
};





