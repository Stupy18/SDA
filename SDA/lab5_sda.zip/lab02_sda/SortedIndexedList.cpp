#include "ListIterator.h"
#include "SortedIndexedList.h"

using namespace std;

#include <exception>

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
SortedIndexedList::SortedIndexedList(Relation r) {
    length = 0;
    head = nullptr;
    tail = nullptr;
    this->r = r;
}

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
int SortedIndexedList::size() const {
    return length;
}

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
bool SortedIndexedList::isEmpty() const {
    return size() == 0;
}

//Average: O(n)
//Worst: O(n) - wenn der Element nicht existiert
//Best: O(1) - wenn der Element am Anfang der Liste sich befindet
TComp SortedIndexedList::getElement(int i) const {
    if (i < 0 || i >= size()) {
        throw exception();
    }
    Node *current = head;
    for (int j = 0; j < i; j++) {
        current = current->next;
    }
    return current->info;
}

//Average: O(n)
//Worst: O(n) - wenn der Element nicht existiert
//Best: O(1) - wenn der Element am Anfang der Liste sich befindet
TComp SortedIndexedList::remove(int i) {
    if (i < 0 || i >= length) {
        throw exception();
    }
    Node *current = head;
    for (int j = 0; j < i; j++) {
        current = current->next;
    }
    TComp removed = current->info;
    if (current == head && current == tail) { //das heist das unser Element allein in der Liste ist,
        // also stellen wir head und tail auf Null ptr
        head = nullptr;
        tail = nullptr;
    } else if (current == head) {//das heist das unser Element der erste in der Liste ist(also head),
        // also setzt man den head auf den nachsten Knoten und aktualisiert den vorherigen Zeiger des neuen head auf nullptr.
        head = head->next;
        if (head != nullptr) {
            head->prev = nullptr;
        }
    } else if (current == tail) {//das heist das unser Element der letzte in der Liste ist(also Tail), aber es gibt weitere Knoten davor,
        // also setzt man den tail auf den vorherigen Knoten und aktualisiert den nachsten Zeiger des neuen tail auf nullptr.
        tail = tail->prev;
        if (tail != nullptr) {
            tail->next = nullptr;
        }
    } else { //Wenn der Knoten am Index i in der Mitte der Liste liegt, aktualisiert es den nächsten Zeiger des vorherigen Knotens,
        // um auf den nächsten Knoten zu zeigen, und aktualisiert den vorherigen Zeiger des nächsten Knotens,
        // um auf den vorherigen Knoten zu zeigen.
        current->prev->next = current->next;
        current->next->prev = current->prev;
    }
    length--;
    delete current;
    return removed;
}

//Average: O(n)
//Worst: O(n) - wenn der Element nicht existiert
//Best: O(1) - wenn der Element am Anfang der Liste sich befindet
int SortedIndexedList::search(TComp e) const {
    int i = 0;
    Node *current = head;
    while (current != nullptr && r(current->info, e)) {
        if (current->info == e) {
            return i;
        }
        i++;
        current = current->next;
    }
//    if (current == nullptr || (current->info != e)) {
    return -1;
//    }
}


//Average: O(n)
//Worst: O(n) - wenn der Element nicht existiert
//Best: O(1) - wenn der Element am Anfang der Liste sich befindet
void SortedIndexedList::add(TComp e) {
    Node *newNode = new Node;
    newNode->info = e;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    //ein neues Element(Node) initialisieren
    if (head == nullptr) { //Wenn die Liste leer ist, wird der neue Element sowohl head als auch tail.
        head = newNode;
        tail = newNode;
    } else {
        Node *current = head;
        while (current != nullptr && r(current->info, e)) {
            current = current->next;
        } //Wenn die Liste nicht leer ist, wird ein Zeiger current auf den head der Liste gesetzt.
        // Dann wird durch die Liste iteriert, um die richtige Position fur das einzufugende Element zu finden.
        // Wenn das aktuelle Element kleiner/grosser oder gleich dem einzufugenden Element ist, wird das nachste Element betrachtet.
        // Dies wird fortgesetzt, bis das aktuelle Element grosser/kleiner als das einzufugende Element ist oder das Ende der Liste erreicht wurde.
        if (current == head) {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        } //Wenn die Einfugeposition das erste Element der Liste ist, wird der neue Knoten zum head der Liste und der nachste Knoten
            // des neuen Knotens wird auf den vorherigen head gesetzt, um die restliche Liste zu verbinden.
        else if (current == nullptr) {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        } //Wenn das einzufugende Element grosser als alle vorhandenen Elemente in der Liste ist, wird der neue Knoten
            // zum tail der Liste und der vorherige Knoten des neuen Knotens wird auf den alten tail gesetzt, um die restliche Liste zu verbinden.
        else {
            newNode->next = current;
            newNode->prev = current->prev;
            current->prev->next = newNode;
            current->prev = newNode;
        } //Wenn das einzufugende Element irgendwo in der Mitte der Liste eingefugt wird, wird der neue Knoten zwischen
        // den beiden benachbarten Knoten platziert und die Zeiger der vorherigen und nachsten Knoten werden aktualisiert, um den neuen Knoten einzufugen.
    }
    length++;
}

//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
ListIterator SortedIndexedList::iterator() {
    return ListIterator(*this);
}

//destructor
//Worst case: Teta(1)
//Best case: Teta(1)
//Average case: Teta(1)
SortedIndexedList::~SortedIndexedList() {
    while (head != nullptr) {
        Node *current = head;
        head = head->next;
        delete current;
    }
}
